All projects here are used for testing on board for each category, please "*.xpr" with Vivado, then:  

0. Open vivado
1. Cd to your proj_path in tcl console  
example: cd B:/Complex_Mind/FPGA-Imaging-Library/PLv1.0/TestOnBoard/Geometry  
2. Tcl Console: source bulid.tcl   
3. Export Hardware
4. Lanch SDK
5. Create new application project  
6. copy codes in ForBuild/Main.c to your Main.c
7. Change setting and run